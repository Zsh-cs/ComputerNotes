package com.zsh.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * 项目异常统一处理
 */
@RestControllerAdvice// REST风格
public class ProjectExceptionAdvice {

    @ExceptionHandler(Exception.class)// 拦截所有异常并处理
    public Result handleException(Exception e) {
        System.out.println("catch an exception...");
        return new Result(666, null, "catch an exception");
    }
}
