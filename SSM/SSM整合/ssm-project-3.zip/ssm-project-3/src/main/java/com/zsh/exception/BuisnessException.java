package com.zsh.exception;

public class BuisnessException extends RuntimeException {
    private Integer code;

    public BuisnessException(Integer code, String message) {
        super(message);
        this.code = code;
    }

    public BuisnessException(Integer code, String message, Throwable cause) {
        super(message, cause);
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
}
